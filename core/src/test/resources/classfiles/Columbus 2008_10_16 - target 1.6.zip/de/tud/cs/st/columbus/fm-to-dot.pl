traverseConcept(C) :- 
	write('digraph G {\n'), traverseFeature(1,1,C),write('}\n').

traverseFeature(LvlID,FID,F) :- 
	(atom(F), write(F),write(';\n')); (functor(F,Name,_),F =..[_|[FG]],traverseFeatureGroups(LvlID,FID,1,Name,FG)).

traverseFeatureGroups(_,_,_,_,[]).
traverseFeatureGroups(LvlID,FID,GrpID,PFName,[FG|FGS]) :- 
	writeEdges(PFName,FG),traverseFeatureGroup(LvlID,FID,GrpID,FG),NextGrpID is GrpID+1,traverseFeatureGroups(LvlID,FID,NextGrpID,PFName,FGS).
writeEdges(PFName,(_,FS)) :- 
	writeEdges(PFName,FS).
writeEdges(_,[]).
writeEdges(PFName,[F|FS]) :- 
	w([PFName,'->']),
	((atom(F),w(F));
	functor(F,Name,_),w(Name)),w(';\n'),writeEdges(PFName,FS).

traverseFeatureGroup(LvlID,FID,GrpID,(C,FS)) :- 
	w(['subgraph cluster',LvlID,'_',GrpID,'_',FID,' {\n labeljust=l; label="',C,'";\n']),
	NextLvlID is LvlID+1,traverseFeatures(NextLvlID,FID,FS),w('}\n').

traverseFeatures(_,_,[]) :- !.
traverseFeatures(LvlID,FID,[F|FS]) :- 
	traverseFeature(LvlID,FID,F), NextFID is FID +1, traverseFeatures(LvlID,NextFID,FS).

w([]).
w(A) :- atom(A), write(A).
w([E|L]) :- write(E),w(L).

% EXAMPLE DATA:
% fm('de.tud.cs.st.columbus.demo.InputService','InputService'([([oneof],['GUI'([([oneof],['SWT','Swing'])]),'Console'])])).
% fm('de.tud.cs.st.columbus.demo.GreetingService','GreetingService'([([oneof],['GUI','Console']),([atmostone],['Logging']),([atmostone],['Date'([([oneof],['shortDate','longDate'])])])])).
% fm('COMPLEX_TEST','GreetingService'([([oneof],['GUI','Console']),([atmostone],['Logging','InputService'([([oneof],['A'([([oneof],['B','C'])]),'D'])])]),([atmostone],['Date'([([oneof],['shortDate','longDate'])])])])).
% EXAMPLE USAGE: 
% fm('de.tud.cs.st.columbus.demo.InputService',FM),traverse(FM).


