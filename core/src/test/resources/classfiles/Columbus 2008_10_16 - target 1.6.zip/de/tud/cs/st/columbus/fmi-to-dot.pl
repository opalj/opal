traverseConcept(C) :- 
	write('digraph G {\n'), traverseFeature(C),write('}\n').

traverseFeature(F) :-
	(atom(F), write(F),write(';\n')); (functor(F,Name,_), F =..[_|[FG]], traverseFeatureGroups(Name,FG)).

traverseFeatureGroups(_,[]).

traverseFeatureGroups(PFName,[FG|FGS]) :-
	writeEdges(PFName,FG), traverseFeatureGroup(FG), traverseFeatureGroups(PFName,FGS).
	
writeEdges(PFName,(_,FS)) :- 
	writeEdges(PFName,FS).
writeEdges(_,[]).
writeEdges(PFName,[F|FS]) :- 
	w([PFName,'->']),
	((atom(F),w(F)); functor(F,Name,_), w(Name)),
	w(';\n'), writeEdges(PFName,FS).

traverseFeatureGroup([]).
traverseFeatureGroup([F|FS]) :- ((atom(F),w(F)), w(';\n'); 
	traverseFeature(F)).

w([]).
w(A) :- atom(A), write(A).
w([E|L]) :- write(E),w(L).

% EXAMPLE DATA:
% fm('de.tud.cs.st.columbus.demo.InputService','InputService'([([oneof],['GUI'([([oneof],['SWT','Swing'])]),'Console'])])).
% fm('de.tud.cs.st.columbus.demo.GreetingService','GreetingService'([([oneof],['GUI','Console']),([atmostone],['Logging']),([atmostone],['Date'([([oneof],['shortDate','longDate'])])])])).
% fm('COMPLEX_TEST','GreetingService'([([oneof],['GUI','Console']),([atmostone],['Logging','InputService'([([oneof],['A'([([oneof],['B','C'])]),'D'])])]),([atmostone],['Date'([([oneof],['shortDate','longDate'])])])])).
% EXAMPLE USAGE: 
% fm('de.tud.cs.st.columbus.demo.InputService',FM),traverse(FM).


