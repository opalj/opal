oneof(L) :- length(L,1).
atmostone(L) :- length(L,N), N < 2.
nToM(N,M,L) :- length(L,K), N < K+1, K < M+1.
checkConstraint(C, Children) :- write(checkConstraint(C,Children)),Term =.. [C|[Children]], call(Term).
checkConstraints([], _).
checkConstraints([C|Cs], Children):- checkConstraint(C,Children), checkConstraints(Cs,Children).
checkGroups([],[]).
checkGroups([E|Es], [I|Is]) :- checkGroup(E,I), checkGroups(Es,Is). 
checkAllConstraints([],_).
checkAllConstraints([C|Cs],Instance) :- checkConstraint(C,Instance), checkAllConstraints(Cs,Instance).
checkAllFeaturesAllowed([],_).
checkAllFeaturesAllowed([I|Is],AllowedFeatures) :- member(F,AllowedFeatures), functor(F,Name,_), functor(I,Name,_), instance(F,I), checkAllFeaturesAllowed(Is,AllowedFeatures).
checkGroup(Model, Instance) :- Model = (Constraints, AllowedFeatures), checkAllConstraints(Constraints,Instance), checkAllFeaturesAllowed(Instance,AllowedFeatures).
instance_internal(FeatureModel,Instance) :-  FeatureModel =.. [Name | [Elements] ], Instance =.. [Name | [Instances] ],  checkGroups(Elements,Instances).
model_node(FeatureModel,FM) :- functor(FeatureModel,Name,0),!, FM =.. [Name,[]].
model_node(F,F).
instance_node(Instance,IM) :- functor(Instance,Name,0),!, IM =.. [Name, []].
instance_node(I,I).
instance(FeatureModel,Instance) :- model_node(FeatureModel,FM), instance_node(Instance,IM),instance_internal(FM,IM).
possibleList( _FM, [], _Incl, _Excl, [] ).
possibleList( FM, [F|Fs], Incl, Excl, [I|Ls] ) :- functor(F,Fname,_), \+( member(Fname,Excl)), possibleInstance(F,Incl,Excl,I), possibleList(FM, Fs,Incl,Excl,Ls).
possibleList(FM, [F|Fs], Incl, Excl, Ls ) :- functor(F,Fname,_), \+( member(Fname,Incl) ), possibleList(FM, Fs,Incl,Excl,Ls).
possibleInstanceList( FM, (Constraints,Features), Incl, Excl, Instance ) :- possibleList(FM,Features,Incl,Excl,Instance), checkConstraints(Constraints,Instance).
possibleInstanceLists(_FM, [], _InclFeatures, _ExclFeatures, [] ).
possibleInstanceLists(FM, [G|Gs], InclFeatures, ExclFeatures, [IL|ILs] ) :- possibleInstanceList(FM, G,InclFeatures,ExclFeatures,IL), possibleInstanceLists(FM, Gs,InclFeatures,ExclFeatures,ILs).
possibleInstance( FeatureModel, IncludedFeatures, ExcludedFeatures, Instance ) :- functor(FeatureModel,_,0), !, Instance = FeatureModel.
possibleInstance( FeatureModel, IncludedFeatures, ExcludedFeatures, Instance ) :- possibleInstance_internal(FeatureModel,IncludedFeatures,ExcludedFeatures,Instance).
possibleInstance_internal( FeatureModel, IncludedFeatures, ExcludedFeatures, Instance ) :- FeatureModel =.. [Constructor , Groups ],possibleInstanceLists(FeatureModel, Groups, IncludedFeatures, ExcludedFeatures, InstanceList ), Instance =.. [Constructor, InstanceList].
featureInModelGroups(Groups,Feature) :- member( (_,G), Groups),  member(X,G), featuresInModel(X, InnerFeatures),  member(Feature,InnerFeatures).
featuresInModel(Leaf, [LeafName]) :- functor(Leaf,LeafName,0),!.
featuresInModel(Leaf, [LeafName]) :- Leaf =.. [LeafName | [] ], !.
featuresInModel(Node, [NodeName|ListOfFeatures]) :- Node =.. [NodeName, Groups], length(Groups, N), N>0, setof( F, featureInModelGroups(Groups,F), ListOfFeatures).
featureInInstanceGroups(Groups,Feature) :- member( G, Groups), member(X,G), featuresInInstance(X, InnerFeatures),  member(Feature,InnerFeatures).
featuresInInstance(Leaf, [LeafName]) :- functor(Leaf,LeafName,0),!.
featuresInInstance(Leaf, [LeafName]) :- Leaf =.. [LeafName | [] ], !.
featuresInInstance(Node, [NodeName|ListOfFeatures]) :- Node =.. [NodeName, Groups], length(Groups, N), N>0, setof( F, featureInInstanceGroups(Groups,F), ListOfFeatures).
matchingImpl(FM,Instance,Req) :- instance(FM,Instance), featuresInInstance(Instance,Features), subset(Req,Features).
findFMIs(FMN,Reqs,Impls) :- findall(X, (fm(FMN,FM), fmi(X,FMN,Instance), matchingImpl(FM,Instance,Reqs)), Impls).
subset([],_).
subset([X|Xs],Y) :- member(X,Y), subset(Xs,Y).
validFeatureModelGroups([]).
validFeatureModelGroups([(_,FeatureModels)|R]) :- validFeatureModels(FeatureModels), validFeatureModelGroups(R).
validFeatureModels([]).
validFeatureModels([F|Fs]) :- validFeatureModel(F), validFeatureModels(Fs).
validFeatureModel(FM) :- model_node(FM,FMN), FMN =.. [_|[L]], validFeatureModelGroups(L).
disjunct([],_).
disjunct([X|Xs],Y) :- \+(member(X,Y)), disjunct(Xs,Y).
checkFeatureRequirements(Incl,Excl,FS) :- disjunct(Excl,FS), subset(Incl,FS).
